<?php

class database
{

    private $host = "localhost";
    private $db_name = "progettoclassmenager";
    private $username = "root";
    private $password = "";
    public $connessione;

    // get the database connection
    public function getConnection()
    {
        $this->connessione = null;

        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
        } catch (PDOException $exception) {
            echo "Database connection error: " . $exception->getMessage();
        }

        return $this->connessione;
    }
}