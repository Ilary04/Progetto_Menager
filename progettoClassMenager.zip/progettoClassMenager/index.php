<?php

$method= $SERVER_['REQUEST_METHOD'];

$uri = $_SERVER['REQUEST_URI'];

//Rimuove i caratteri lato sinistro stringa
$uri = ltrim($uri, "/");

//Rimuove i caratteri lato destro stringa
$uri = rtrim($uri, "/");

//diventa un array di  elementi.
$uri = explode("/", $uri);

//caratteri in minuscolo 
$s = strtolower($uri[1]);

switch ($s){
    case "classi":
        echo " CLASSI";
        break;
    case "studenti":
        echo "STUDENTI";
        break;
}

?>